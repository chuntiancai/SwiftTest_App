//
//  TestTestMusicVC.swift
//  SwiftTest_App
//
//  Created by ctch on 2024/4/2.
//  Copyright © 2024 com.mathew. All rights reserved.
//

import UIKit

//MARK: - 笔记
/**
    1、如果数据量大，可以开启多线程来拉取数据，然后处理完数据再通知主线程刷新UI
    2、电脑卡到snpkit的联想都打不开
 
 */


class TestTestMusicVC:UIViewController {
    
    //MARK: - 属性
    
    
    
    private var audioModelArr = [MyMusicModel]() //音频model的数组
    var nameArr = ["Agent 51 - Bad Times (Album Version)",
                   "Agent 51 - Been So Long (Album Version)",
                   "Ariana Grande、MAC MILLER - Into You (Alex Ghenea Remix)",
                   "Avril Lavigne - 17",
                   "BEYOND - Amani (粤语)",
                   "Bloc Party - Banquet",
                   "Bon Jovi - Because We Can",
                   "Coldplay - A Message (2005)",
                   "Dream Theater - Another Day",
                   "Ester drang - All The Feeling",
                   "FLOW (フロウ) - 7-seven- (TVアニメ 「七つの大罪」 エンディングテーマ)",
                   "Glen Check - 60's Cardin",
                   "Green Day - 21 Guns (《变形金刚2》电影插曲)",
                   "Groove Coverage - She.flac",
                   "Halestorm - Bad Girl's World",
                   "James Blunt - You're Beautiful - 2006重制版",
                   "Jeff Buckley - Back In N.Y.C.",
                   "Joshua Radin - Beautiful Day",
                   "Lady Gaga - Poker Face",
                   "Matt Nathanson - All We Are",
                   "Miracle Mile - Beginagain",
                   "Nickelback - Animals",
                   "Oh Sunshine - beautiful (japanese ver.)",
                   "OneRepublic - All The Right Moves",
                   "OneRepublic - Apologize",
                   "Paramore - Ain't It Fun",
                   "Rise Against - Behind Closed Doors",
                   "Scorpions - Always Somewhere",
                   "Skid Row - 18 And Life",
                   "Suede - Beautiful Ones",
                   "TFBOYS - 开学第一课 (《开学第一课》节目主题曲)",
                   "TFBOYS - 剩下的盛夏",
                   "The Cranberries - Animal instinct",
                   "The Dunwells - Animal",
                   "The Fray - Be Still",
                   "The Pretty Reckless - Just Tonight",
                   "The Rolling Stones - (I Can't Get No) Satisfaction",
                   "This Is Love-周兴哲"]
    var imgNameArr = ["thumb01", "thumb02", "thumb03", "thumb04", "thumb05", "thumb06",
                      "thumb07", "thumb08", "thumb09", "thumb10", "thumb11", "thumb12",
                      "thumb13", "thumb14", "thumb15", "thumb16", "thumb17", "thumb18",
                      "thumb19", "thumb20", "thumb21", "thumb22", "thumb23", "thumb24",
                      "thumb25"]
    
    
    //MARK: UI属性
    var bgView = UIImageView()
    var addBtn = UIButton()
    var deleBtn = UIButton()

    private var btmView: UIView = { //底部按钮 的view
        let bView = UIView()
        bView.backgroundColor = UIColor.gray
        return bView
    }()
    
    private var tableView:UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.register(MusicCell.self, forCellReuseIdentifier: "MusicCell_ID")

        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = UIColor.clear
        tableView.bounces = true
        tableView.separatorStyle = .none
        
        
        return tableView
    }()

    //MARK: - 复写方法
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "音频"
        self.view.backgroundColor = UIColor(red: 245/255.0, green: 245/255.0, blue: 245/255.0, alpha: 1.0)
        self.edgesForExtendedLayout = .bottom
        testAddMidea()
        initUI()
        
    }
    
    
    
 
}

//MARK: - 设置UI
extension TestTestMusicVC{
    /// 初始化UI
    private func initUI(){
        bgView.image = UIImage(named: "bg")
        view.addSubview(bgView)
        bgView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
       
        
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.snp.makeConstraints { make in
            make.top.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-80)
        }
        
        view.addSubview(btmView)
        btmView.snp.makeConstraints { make in
            make.bottom.left.right.equalToSuperview()
            make.height.equalTo(80)
        }
        
        addBtn.setTitle("添加", for: .normal)
        addBtn.backgroundColor = UIColor.blue
        addBtn.addTarget(self, action: #selector(addBtnAction), for: .touchUpInside)
        addBtn.setTitleColor(UIColor.white, for: .normal)
        addBtn.frame = CGRect(x: 20, y: 20, width: 100, height: 40)
        btmView.addSubview(addBtn)
        
        
        
        deleBtn.setTitle("删除", for: .normal)
        deleBtn.addTarget(self, action: #selector(delBtnAction), for: .touchUpInside)
        deleBtn.backgroundColor = UIColor.red
        deleBtn.setTitleColor(UIColor.white, for: .normal)
        deleBtn.frame = CGRect(x: 160, y: 20, width: 100, height: 40)
        btmView.addSubview(deleBtn)
        
    }
    
}


//MARK: - 遵循tableview的代理协议
extension TestTestMusicVC:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
         return audioModelArr.count
    }
   
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 92
        
    }
    
    ///设置cell的UI
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell!
        //音频
        cell = tableView.dequeueReusableCell(withIdentifier: "MusicCell_ID", for: indexPath) as! MusicCell
//        cell.imageView?.image = UIImage(named: audioModelArr[indexPath.row].imgUrl)
        (cell as? MusicCell)?.setImageUI(img: UIImage(named: audioModelArr[indexPath.row].imgUrl)!)
        (cell as? MusicCell)?.title = audioModelArr[indexPath.row].fileName
        
        return cell
    }

}

//MARK: - 请求网络
extension TestTestMusicVC{
}

//MARK: - 内部工具方法
@objc extension TestTestMusicVC{
    
    func addBtnAction(){
        print("点击了添加按钮")
        
        deleBtn.isEnabled = true
        if audioModelArr.count > 19 {
            addBtn.isEnabled = false
        }
        var randomNumber = 0
        if audioModelArr.count > 1 {
            let count = min(imgNameArr.count,nameArr.count)
            randomNumber = Int(arc4random_uniform(UInt32(count - 1)))
        }
        let imgName = imgNameArr.remove(at: randomNumber)
        let musicName = nameArr.remove(at: randomNumber)
        
        let model  = MyMusicModel(imgUrl: imgName, fileName: musicName)
        
        if audioModelArr.count > 2 {
            audioModelArr.insert(model, at: 2)
        }else{
            audioModelArr.append(model)
        }
        
        self.tableView.reloadData()
    }
    
    func delBtnAction(){
        print("点击了删除按钮")
        addBtn.isEnabled = true
        if audioModelArr.count == 1 {
            deleBtn.isEnabled = false
            let model  = audioModelArr.remove(at: 0)
            nameArr.append(model.fileName)
            imgNameArr.append(model.imgUrl)
            self.tableView.reloadData()
            return
        }
        
        if audioModelArr.count > 1 {
            let model  = audioModelArr.remove(at: 1)
            nameArr.append(model.fileName)
            imgNameArr.append(model.imgUrl)
        }
        self.tableView.reloadData()
    }
    
    /// FIXME:测试用加载音视频列表
    func testAddMidea(){
        
        var modelArr = [MyMusicModel]()
        for i in 0 ... 9 {
            
            let imgName = imgNameArr.remove(at: i)
            let musicName = nameArr.remove(at: i)
            
            let model  = MyMusicModel(imgUrl: imgName, fileName: musicName)
            modelArr.append(model)
        }
        self.audioModelArr = modelArr
    }
        
    
    
    
    
}

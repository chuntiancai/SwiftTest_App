//
//  MyMusicModel.swift
//  SwiftTest_App
//
//  Created by ctch on 2024/4/2.
//  Copyright © 2024 com.mathew. All rights reserved.
//

struct MyMusicModel {
    
    var imgUrl:String = ""
    
    /// 音视频标题
    var fileName: String = ""
    
    
}

//
//  musicCell.swift
//  SwiftTest_App
//
//  Created by ctch on 2024/4/2.
//  Copyright © 2024 com.mathew. All rights reserved.
//

import UIKit
import CoreGraphics

class MusicCell: UITableViewCell {
    
    //MARK: - 对外属性
    /// 标题
    var title:String?{
        didSet{
            titleLab.text = title
        }
    }
    
    
    
    //MARK: - 内部属性
    private var titleLab: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.font = UIFont.systemFont(ofSize: 16)
        return lab
    }()
    
    var imgView = UIImageView()
    var maskImgView = UIImageView(frame: CGRect(x: 0, y: 0, width: 70, height: 70))
    

    //MARK: - 复写方法
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        clipsToBounds = true
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
//        self.textLabel?.textColor = UIColor.white
        
        createUI()
    }
    
    override func removeFromSuperview() {
        super.removeFromSuperview()
    }
    
    ///cell准备被复用的时候
    override func prepareForReuse() {
        super.prepareForReuse()
        self.imageView?.mask = nil
//        self.imageView?.layer.cornerRadius = 10
//        self.imageView?.transform = .identity   //重置transform属性。
//        self.imageView?.transform = CGAffineTransform.init(scaleX: 2, y: 0.8)
    }
    
   
    func setImageUI(img:UIImage){
        /**
            1、目前还不知道原生的img的影响，我的思路本来是在contentview里自定义imgview的。
            2、还不行的话就自定义view，在draw方法里面绘制图片的layer
         */
        
        imgView.image = img
        imgView.mask = maskImgView
        
//        let maskImg = UIImage(named: "frame")!
//        let maskView = UIImageView(image: maskImg)
//        maskView.frame = CGRect(x: 0, y: 0, width: 70, height: 70)
//
//
//        self.imageView?.image = UIImage(named: "frame")
//        self.imageView?.mask = maskView
    }
    
    

}
//MARK: - 设置UI
extension MusicCell {
    
   
    /// 创建基本的UI
    private func createUI() {
        
        maskImgView.image = UIImage(named: "frame")
        
        self.contentView.addSubview(imgView)
        imgView.contentMode = .scaleAspectFit
        imgView.snp.makeConstraints { make in
            make.width.height.equalTo(70)
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(23)
        }
        
        self.contentView.addSubview(titleLab)
        titleLab.numberOfLines = 0
        titleLab.snp.makeConstraints { make in
            make.top.equalTo(imgView)
            make.right.equalToSuperview().offset(-23)
            make.left.equalTo(imgView.snp.right).offset(20)
        }
        
    }
}

//MARK: - 对外提供的方法
extension MusicCell {
    
   
}

